<?php 
namespace Motniemtin\AddVideo;

use Exception;
use Motniemtin\Auto\Auto;
use Motniemtin\Auto\AutoProxy;
class Freescores{
  var $user;
  var $pass;
  var $auto;
  function __construct($user,$pass){
    $this->user=$user;
    $this->pass=$pass;
    $this->auto=new Auto(1,"freescores.com.txt");
  }
  function login($url){
    $html=$this->auto->Get($url);
    if(substr_count($html,$this->user)==0){
      $html=$this->auto->Post("https://www.free-scores.com/espace-membres-uk/verification_login.php","pseudo".$this->user."=&password=".$this->pass."&modal=&urlref=".urlencode("http://www.free-scores.com/espace-membres-uk/?url=".urlencode($url)),$url);
      if(substr_count($html,$this->user)==0){
        throw new Exception("error to Login to https://www.free-scores.com");
      }
    }
    echo "login free-scores ok\n";
  }
  public function postYoutube($url,$youtube_id){
    $youtube_url="https://www.youtube.com/watch?v=".$youtube_id;
    $this->post($url,$youtube_url);
  }
  public function postDailymotion($url,$dailymotion_id){
    $dailymotion_url="https://www.dailymotion.com/video/".$dailymotion_id;
    $this->post($url,$dailymotion_url);
  }  
  public function post($url,$video_url){
    if(substr_count($url,"?pdf=")==0){
      throw new Exception("Error url, pdf= not found, can't post video to free scores..\n");
    }
    $post_id=explode("?pdf=",$url);
    $post_id=end($post_id);
    $post_id=(int)$post_id;
    if($post_id==0){
      throw new Exception("Error find post id, can't post video to free scores..\n");
    }
    $this->login($url);
    $html=$this->auto->Get("http://www.free-scores.com/espace-membres-uk/add_videos.php?URL=".urlencode($video_url)."&submit=SAVE&clef_partition=$post_id&modal=1&partition=$post_id&ok=1");
    if(substr_count($html,"informed by mail")>0){
      echo "post to free scores ok !\n";
    }else{
      echo "post to free scores error $html!\n";
    }
  }
}